pipeline {
  agent any
  
  environment {
       //分支
       //BRANCH = "dev"
       //ssh使用的用户
	   SSH_USER = "ops"
	   //ssh到目标主机的端口
	   SSH_PORT = "62222"
       KEY_DIR="/var/lib/jenkins/key/id_rsa"
	   //目标主机
	   DEST_HOST = "172.16.9.149"
	   //git地址
       GIT_URL = "git@gitlab.go016.com:payment-back/ims-${SERVICE_NAME}.git"
       PAY_DIR1 = "lb1-pay-api"
       PAY_DIR2 = "lb2-pay-api"
       DRAWAL_DIR1 = "lb1-drawal"
       DRAWAL_DIR2 = "lb2-drawal"
       ADMIN_DIR = "lb1-pay-admin"
  }
  parameters {
    gitParameter branch: '', branchFilter: '.*', defaultValue: 'ali-test', description: '选择你的代码分支', name: 'BRANCH', quickFilterEnabled: false, selectedValue: 'NONE', sortMode: 'NONE', tagFilter: '*', type: 'GitParameterDefinition'
  }
  stages {
    stage('拉代码'){
			when {
				environment name: 'ACT',
				value: 'update'
			}
		steps{
		  checkout([$class: 'GitSCM', branches: [[name: "${BRANCH}"]],  userRemoteConfigs: [[credentialsId: 'ssh-git-key', url: "${GIT_URL}"]]])
		}
	}
	
    stage('编译'){
			when {
				environment name: 'ACT',
				value: 'update'
			}
		steps{
			withMaven(maven: 'v3.6.3') {
			//mvn构建
			sh "mvn clean install -Dmaven.test.skip=true "
			}
		}
	}
	
    
    stage('推送支付包并重启'){
			when {
				allOf{
					environment name: 'ACT',
					value: 'update';
					environment name: 'SERVICE_NAME',
					value: 'pay-api';
				}
			}
		steps{
          sh"""
             scp -i ${KEY_DIR}  -o StrictHostKeyChecking=no -P ${SSH_PORT} admin/target/ims-${SERVICE_NAME}.jar  ${SSH_USER}@${DEST_HOST}:/usr/local/src/java/${PAY_DIR1}/ && \
             scp -i ${KEY_DIR}  -o StrictHostKeyChecking=no -P ${SSH_PORT} admin/target/ims-${SERVICE_NAME}.jar  ${SSH_USER}@${DEST_HOST}:/usr/local/src/java/${PAY_DIR2}/ && \
             sleep 5 && \
            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p ${SSH_PORT} ${SSH_USER}@${DEST_HOST}  "sudo systemctl restart ${PAY_DIR1}.service" && \
            sleep 40 && \
            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p ${SSH_PORT} ${SSH_USER}@${DEST_HOST}  "sudo systemctl restart ${PAY_DIR2}.service"
          """
		}
	}
    
    stage('推送代付包并重启'){
			when {
				allOf{
					environment name: 'ACT',
					value: 'update';
					environment name: 'SERVICE_NAME',
					value: 'drawal-api';
				}
			}
		steps{
          sh"""
             scp -i ${KEY_DIR}  -o StrictHostKeyChecking=no -P ${SSH_PORT} admin/target/ims-${SERVICE_NAME}.jar  ${SSH_USER}@${DEST_HOST}:/usr/local/src/java/${DRAWAL_DIR1}/ && \
             scp -i ${KEY_DIR}  -o StrictHostKeyChecking=no -P ${SSH_PORT} admin/target/ims-${SERVICE_NAME}.jar  ${SSH_USER}@${DEST_HOST}:/usr/local/src/java/${DRAWAL_DIR2}/ && \
             sleep 5 && \
            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p ${SSH_PORT} ${SSH_USER}@${DEST_HOST}  "sudo systemctl restart ${DRAWAL_DIR1}.service" && \
            sleep 40 && \
            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p ${SSH_PORT} ${SSH_USER}@${DEST_HOST}  "sudo systemctl restart ${DRAWAL_DIR2}.service"
          """
        }
	}
    
    stage('推送后台包并重启'){
			when {
				allOf{
					environment name: 'ACT',
					value: 'update';
					environment name: 'SERVICE_NAME',
					value: 'pay-admin';
				}
			}
		steps{
          sh"""
             scp -i ${KEY_DIR}  -o StrictHostKeyChecking=no -P ${SSH_PORT} admin/target/ims-${SERVICE_NAME}.jar  ${SSH_USER}@${DEST_HOST}:/usr/local/src/java/${ADMIN_DIR}/ && \
             sleep 5 && \
             ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p ${SSH_PORT} ${SSH_USER}@${DEST_HOST}  "sudo systemctl restart ${ADMIN_DIR}.service"

          """
		}
	}
    
    stage('支付服务重启'){
			when {
				allOf{
					environment name: 'ACT',
					value: 'restart';
					environment name: 'SERVICE_NAME',
					value: 'pay-api';
				}
			}
		steps{
          sh"""
            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p ${SSH_PORT} ${SSH_USER}@${DEST_HOST}  "sudo systemctl restart ${PAY_DIR1}.service" && \
            sleep 40 && \
            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p ${SSH_PORT} ${SSH_USER}@${DEST_HOST}  "sudo systemctl restart ${PAY_DIR2}.service"
          """
		}
	}
    
    
    stage('代付服务重启'){
			when {
				allOf{
					environment name: 'ACT',
					value: 'restart';
					environment name: 'SERVICE_NAME',
					value: 'drawal-api';
				}
			}
		steps{
          sh"""
            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p ${SSH_PORT} ${SSH_USER}@${DEST_HOST}  "sudo systemctl restart ${DRAWAL_DIR1}.service" && \
            sleep 40 && \
            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p ${SSH_PORT} ${SSH_USER}@${DEST_HOST}  "sudo systemctl restart ${DRAWAL_DIR2}.service"
          """
		}
	}
    
    stage('后台服务重启'){
			when {
				allOf{
					environment name: 'ACT',
					value: 'restart';
					environment name: 'SERVICE_NAME',
					value: 'pay-admin';
				}
			}
		steps{
          sh"""
            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p ${SSH_PORT} ${SSH_USER}@${DEST_HOST}  "sudo systemctl restart ${ADMIN_DIR}.service"
          """
		}
	}
    
    stage('支付服务停止'){
			when {
				allOf{
					environment name: 'ACT',
					value: 'stop';
					environment name: 'SERVICE_NAME',
					value: 'pay-api';
				}
			}
		steps{
          sh"""
            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p ${SSH_PORT} ${SSH_USER}@${DEST_HOST}  "sudo systemctl stop ${PAY_DIR1}.service" && \
            sleep 4 && \
            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p ${SSH_PORT} ${SSH_USER}@${DEST_HOST}  "sudo systemctl stop ${PAY_DIR2}.service"
          """
		}
	}
    
    
    stage('代付服务停止'){
			when {
				allOf{
					environment name: 'ACT',
					value: 'stop';
					environment name: 'SERVICE_NAME',
					value: 'drawal-api';
				}
			}
		steps{
          sh"""
            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p ${SSH_PORT} ${SSH_USER}@${DEST_HOST}  "sudo systemctl stop ${DRAWAL_DIR1}.service" && \
            sleep 4 && \
            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p ${SSH_PORT} ${SSH_USER}@${DEST_HOST}  "sudo systemctl stop ${DRAWAL_DIR2}.service"
          """
		}
	}
    
    stage('后台服务停止'){
			when {
				allOf{
					environment name: 'ACT',
					value: 'stop';
					environment name: 'SERVICE_NAME',
					value: 'pay-admin';
				}
			}
		steps{
          sh"""
            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p ${SSH_PORT} ${SSH_USER}@${DEST_HOST}  "sudo systemctl stop ${ADMIN_DIR}.service"
          """
		}
	}

  }

}