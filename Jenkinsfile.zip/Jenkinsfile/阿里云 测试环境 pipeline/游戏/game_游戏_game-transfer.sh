pipeline {
  agent any
  environment {
	GIT_URL="git@gitlab.go016.com:game/third-game-transfer.git"
	KEY_DIR="/var/lib/jenkins/key/id_rsa"
    HOST = "172.16.9.165"
    APP_NAME = "game-transfer"
    DPATH = "/usr/local/src/java/${APP_NAME}/"
    BUILD_DIR = "."
    JAR_NAME = "third-game-transfer-0.0.1-SNAPSHOT.jar"
    JAR_PATH = "${BUILD_DIR}/target/${JAR_NAME}"
  }
  tools {
      jdk 'se8'
  }
  parameters {
  gitParameter branch: '', branchFilter: '.*', defaultValue: 'test', description: '选择你的代码分支', name: 'BRANCH', quickFilterEnabled: false, selectedValue: 'NONE', sortMode: 'NONE', tagFilter: '*', type: 'GitParameterDefinition'
  }
  stages {
    stage('拉代码') {
        steps {
            checkout([$class: 'GitSCM', branches: [[name: "${BRANCH}"]], extensions: [], userRemoteConfigs: [[credentialsId: 'ssh-git-key', url: "${GIT_URL}"]]])
        }
    }
    stage('编译代码') {
        steps {
            withMaven(maven: 'v3.5') {
              sh """
                cd ${BUILD_DIR} && mvn clean install -Dmaven.test.skip=true 
              """
            }
        }
    }

    stage('发包并重启服务') {
        steps {
            sh """
               pwd
               ssh -i ${KEY_DIR} -p 62222 -o StrictHostKeyChecking=no ops@${HOST} "rm -rf ${DPATH}/${JAR_NAME}_bak ; touch ${DPATH}/${JAR_NAME} ; mv ${DPATH}/${JAR_NAME} ${DPATH}/${JAR_NAME}_bak"
               scp -i ${KEY_DIR} -P 62222 -o StrictHostKeyChecking=no ${JAR_PATH}  ops@${HOST}:${DPATH} && \
               sleep 3 && \
               ssh -i ${KEY_DIR} -p 62222 -o StrictHostKeyChecking=no ops@${HOST} "sudo systemctl enable ${APP_NAME} && sudo systemctl restart ${APP_NAME}"
            """
        }
    }
    
    

   }
}