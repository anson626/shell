pipeline {
  agent {
	kubernetes {
		cloud 'test'
		inheritFrom 'nodejs'
	}
  }
  environment {
      APP_NAME = "h5-web"
      REGISTRY = "test-ali-hub.go043.com:6443"
	  DOCKERHUB_NAMESPACE = "pay"
	  //git
	  GIT_ID = "ssh-git-key"
	  //GIT_URL
	  GIT_URL = "git@gitlab.go016.com:payment-front/yinshang_h5.git"
	  //k8s
	  NAMESPACE = "yinshang"
	  replicas = "1"
	  
  }
    parameters {
        gitParameter branch: '', branchFilter: '.*', defaultValue: 'master', description: '选择git分支', name: 'BRANCH', quickFilterEnabled: false, selectedValue: 'NONE', sortMode: 'NONE', tagFilter: '*', type: 'GitParameterDefinition'
   }

  stages {
    stage('拉取代码'){
	  steps {  
        checkout([$class: 'GitSCM', branches: [[name: "${BRANCH}"]], doGenerateSubmoduleConfigurations: false, extensions: [[
                                                $class: 'SubmoduleOption', 
                                                disableSubmodules: false, 
                                               parentCredentials: true, 
                                                recursiveSubmodules: true, 
                                                reference: '', 
                                                trackingSubmodules: false
                                              ]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: "${GIT_ID}", url: "${GIT_URL}"]]])

	  }
	}
	
    stage('生成nginx配置'){
	  steps {  
        sh '''cat >frontend.conf<<EOF
server {
   listen       80 default_server;
   server_name  _;
   gzip on;
   gzip_min_length  5k;
   gzip_buffers     4 16k;
   gzip_http_version 1.0;
   gzip_comp_level 3;
   gzip_types     image/jpeg image/gif image/png image/ico text/plain application/x-javascript text/css text/javascript application/apk  application/json;
   gzip_vary on;
   gzip_disable "MSIE [1-6].";
   charset utf-8;

   location / {
        root /home/html/;
        index  index.html index.htm;
        try_files \\$uri \\$uri/ /index.html;
   }
   

   location ~* ^/(v1) {
        rewrite ^/v1/(.+?)$ /\\$1 break; 
        proxy_pass       http://api.yinshang:8080;
        proxy_set_header Host      \\$host;
        proxy_set_header X-Real-IP \\$remote_addr;
        proxy_set_header X-Forwarded-For \\$proxy_add_x_forwarded_for;
   }
   
  location ^~ /ysImage/ {
      rewrite ^/ysImage/(.+?)$ /\\$1 break; 
      proxy_pass http://api.yinshang:8080/;
      proxy_set_header Host      \\$host;
      proxy_set_header X-Real-IP \\$remote_addr;
      proxy_set_header X-Forwarded-For \\$proxy_add_x_forwarded_for;
  }

   location ~ \\.(html|htm|gif|jpg|jpeg|bmp|png|ico|txt|js|css|woff|woff2|eot|otf|svg|ttf|psd|jade|less|scss|json|xls|xlsx)$ {
      root /home/html/;
   }

}
EOF
'''
	  }
	}
	
    stage('生成dockerfile'){
	  steps {  
      sh '''cat >Dockerfile <<'EOF'
FROM nginx
ENV TZ=Asia/Shanghai
RUN ln -snf /usr/share/zoneinfo/$TZ /etc/localtime && echo $TZ > /etc/timezone
RUN mkdir /home/html
COPY ./frontend.conf /etc/nginx/conf.d/frontend.conf
COPY ./prod/ /home/html
EXPOSE 80
EOF
'''
	  }
	}
	
    stage('代码编译'){
	  steps {  
		container('nodejs') {
			sh 'apk add zip &&npm install && npm run build'
		}
	  }
	}
	
    stage('docker build 和 推送'){
	  steps {  
		container('docker') {
			sh 'docker build -f Dockerfile -t $REGISTRY/$DOCKERHUB_NAMESPACE/$APP_NAME:TEST-$BUILD_NUMBER .'
			withCredentials([usernamePassword(credentialsId: 'harbor_id', passwordVariable: 'P', usernameVariable: 'U')]) {
                sh 'echo "$P" | docker login $REGISTRY -u "${U}" --password-stdin && docker push $REGISTRY/$DOCKERHUB_NAMESPACE/$APP_NAME:TEST-$BUILD_NUMBER'
				}
		}
	  }
	}
	
	
    stage('生成资源清单'){
	  steps {  
      sh '''cat >k8s.yml<<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ${APP_NAME}
  namespace: ${NAMESPACE}
  labels:
    app: ${APP_NAME}
spec:
  replicas: ${replicas}
  strategy:
    rollingUpdate:
      maxSurge: 1
      maxUnavailable: 1
  selector:
    matchLabels:
      app: ${APP_NAME}
  template:
    metadata:
      labels:
        app: ${APP_NAME}
    spec:
      containers:
        - name: ${APP_NAME}
          image: $REGISTRY/$DOCKERHUB_NAMESPACE/$APP_NAME:TEST-$BUILD_NUMBER
          ports:
            - containerPort: 80

---
apiVersion: v1
kind: Service
metadata:
  labels:
    app: ${APP_NAME}
  name: ${APP_NAME}
  namespace: ${NAMESPACE}
spec:
  ports:
    - port: 80
      targetPort: 80
  selector:
    app: ${APP_NAME}
  type: ClusterIP
EOF
''' 

      sh "cat k8s.yml" 

	  }
	}
	
    stage('部署到K8S '){
	  steps {  
         kubernetesDeploy configs: 'k8s.yml', kubeconfigId: 'kubeconfig'
         
	  }
	}
	
  }
}