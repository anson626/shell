pipeline {
  agent {
	kubernetes {
		cloud 'test'
		inheritFrom 'java8'
	}
  }
  environment {
       //定义环境变量
       NAME = "mgt"
       REGISTRY = 'test-ali-hub.go043.com:6443'
       REGISTRY_ns = "pay"
       IMAGE_TAG = "${REGISTRY}/${REGISTRY_ns}/${NAME}:${BUILD_NUMBER}"
       K8S_NS = "yuletong"
       POD_NUMBER = "1"
       POD_PORT = "8080"
       NodePort = "30109"
       GIT_URL = "git@gitlab.go016.com:payment-back/yuletong.git"
       GIT_ID = "ssh-git-key"
       SECRETS = "yuletong"
       TIDB_DATA = "yuletong"
       UID_DB = "subo_rbac_test"
       
  }
  parameters {
        gitParameter branch: '', branchFilter: '.*', defaultValue: 'feature/test', description: '选择git分支', name: 'BRANCH', quickFilterEnabled: false, selectedValue: 'NONE', sortMode: 'NONE', tagFilter: '*', type: 'GitParameterDefinition'
   }

  //阶段汇总
  stages {
    //阶段
    stage('拉取代码'){
	  steps {
        checkout([$class: 'GitSCM', branches: [[name: "${BRANCH}"]], doGenerateSubmoduleConfigurations: false, extensions: [[
                                                $class: 'SubmoduleOption', 
                                                disableSubmodules: false, 
                                                parentCredentials: true, 
                                                recursiveSubmodules: true, 
                                                reference: '', 
                                                trackingSubmodules: false
                                              ]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: "${GIT_ID}", url: "${GIT_URL}"]]])

	  }
	}
    

    
    stage('编译'){
	  steps {
         container('maven') {
             sh './yuletong/gradlew clean :yuletong:build -x test'
         }
	  }
	}

    stage('生成dockerfile'){
	  steps {
	     sh '''
         cat >Dockerfile<<'EOF'
FROM test-ali-hub.go043.com:6443/pay/openjdk:8u332-jdk
VOLUME /tmp
ENV TZ=Asia/Shanghai
RUN ln -snf /usr/share/zoneinfo/$TZ /etc/localtime && echo $TZ > /etc/timezone
ADD yuletong/build/libs/*.jar /app.jar
ENV JAVA_OPTS="-Xms256m"
ENTRYPOINT [ "sh", "-c", "java $JAVA_OPTS -Djava.security.egd=file:/dev/./urandom -jar /app.jar" ]
EXPOSE 8080
EOF
        cat Dockerfile
         '''
	  }
	}

    stage('构建docker镜像'){
	  steps {
        container('docker') {
            sh """
            docker build . -t ${IMAGE_TAG}
            """
        }
	  }
	}
    
    stage('推送docker镜像'){
	  steps {
        container('docker') {
          withCredentials([usernamePassword(credentialsId: 'harbor_id', passwordVariable: 'P', usernameVariable: 'U')]) {
	        sh """
              echo ${P} |docker login $REGISTRY -u "${U}" --password-stdin && \
              docker push ${IMAGE_TAG}
            """
          }
        }
	  }
	}
    
    stage('生成资源清单'){
	  steps {
	     sh """
         cat >k8s.yaml<<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ${NAME}
  namespace: ${K8S_NS}
  labels:
    app: ${NAME}
spec:
  replicas: ${POD_NUMBER}
  template:
    metadata:
      name: ${NAME}
      labels:
        app: ${NAME}
    spec:
      containers:
        - name: ${NAME}
          image: ${IMAGE_TAG}
          imagePullPolicy: IfNotPresent
          resources:
            requests:
              cpu: 200m
              memory: 1Gi
            limits:
              cpu: 500m
              memory: 2Gi
          readinessProbe:
            initialDelaySeconds: 60
            periodSeconds: 30
            tcpSocket:
              port: ${POD_PORT}
          livenessProbe:
            initialDelaySeconds: 60
            periodSeconds: 30
            tcpSocket:
              port: ${POD_PORT}
          env:
            - name: MARIADB_DATABASE
              value: ${UID_DB}
            - name: MYSQL_DATABASE
              value: ${TIDB_DATA}
            - name: MYSQL_HOST
              valueFrom:
                secretKeyRef:
                  name: ${SECRETS}
                  key: MYSQL_HOST
            - name: MYSQL_PORT
              valueFrom:
                secretKeyRef:
                  name: ${SECRETS}
                  key: MYSQL_PORT
            - name: MYSQL_USERNAME
              valueFrom:
                secretKeyRef:
                  name: ${SECRETS}
                  key: MYSQL_USERNAME
            - name: MYSQL_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: ${SECRETS}
                  key: MYSQL_PASSWORD
            - name: NAMESPACE
              valueFrom:
                secretKeyRef:
                  name: ${SECRETS}
                  key: NAMESPACE
            - name: REGISTER_HOST
              valueFrom:
                secretKeyRef:
                  name: ${SECRETS}
                  key: REGISTER_HOST
            - name: REGISTER_PORT
              valueFrom:
                secretKeyRef:
                  name: ${SECRETS}
                  key: REGISTER_PORT
            - name: PASSWORD
              valueFrom:
                secretKeyRef:
                  name: ${SECRETS}
                  key: PASSWORD
            - name: USERNAME
              valueFrom:
                secretKeyRef:
                  name: ${SECRETS}
                  key: USERNAME
            - name: REDIS_HOST
              valueFrom:
                secretKeyRef:
                  name: ${SECRETS}
                  key: REDIS_HOST
            - name: REDIS_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: ${SECRETS}
                  key: REDIS_PASSWORD
            - name: REDIS_PORT
              valueFrom:
                secretKeyRef:
                  name: ${SECRETS}
                  key: REDIS_PORT
            - name: MARIADB_HOST
              valueFrom:
                secretKeyRef:
                  name: ${SECRETS}
                  key: MARIADB_HOST
            - name: MARIADB_PORT
              valueFrom:
                secretKeyRef:
                  name: ${SECRETS}
                  key: MARIADB_PORT
            - name: MARIADB_USERNAME
              valueFrom:
                secretKeyRef:
                  name: ${SECRETS}
                  key: MARIADB_USERNAME
            - name: MARIADB_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: ${SECRETS}
                  key: MARIADB_PASSWORD
      restartPolicy: Always
  selector:
    matchLabels:
      app: ${NAME}
---
apiVersion: v1
kind: Service
metadata:
  name: ${NAME}
  namespace: ${K8S_NS}
spec:
  selector:
    app: ${NAME}
  ports:
    - port: ${POD_PORT}
      targetPort: ${POD_PORT}
      nodePort: ${NodePort}
  type: NodePort

EOF
         cat k8s.yaml
         """
	  }
	}
    
    stage('部署到集群'){
	  steps {
	     kubernetesDeploy configs: 'k8s.yaml', kubeconfigId: 'kubeconfig'
	  }
	}
    
  }
}