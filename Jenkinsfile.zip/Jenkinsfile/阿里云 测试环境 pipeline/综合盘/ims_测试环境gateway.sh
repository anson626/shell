pipeline {
  agent any
  environment {
	//包路径
	//SRC_DIR="/projects/backend/global-pf/"
	GIT_URL="git@gitlab.go016.com:pt-back/ims-gateway.git"
	KEY_DIR="/var/lib/jenkins/key/id_rsa"
  }
  parameters {
    gitParameter branch: '', branchFilter: '.*', defaultValue: 'test-aliyun', description: '选择你的代码分支', name: 'BRANCH', quickFilterEnabled: false, selectedValue: 'NONE', sortMode: 'NONE', tagFilter: '*', type: 'GitParameterDefinition'
  }
  stages {
    stage('拉代码') {
        steps {
            checkout([$class: 'GitSCM', branches: [[name: "${BRANCH}"]], extensions: [], userRemoteConfigs: [[credentialsId: 'ssh-git-key', url: "${GIT_URL}"]]])
        }
    }
    stage('编译代码') {
        steps {
            sh """
            mvn clean install -Dmaven.test.skip=true
            """
        }
    }
    stage('更新admin主机运行的包') {
	  parallel {
	      //admin主机 
	      stage('ims-gateway') {
			  steps {
				sh """
					if [[ "${admin_server}" =~ "gateway" ]]
					then
					    for HOST in ${DEST_HOSTS};
					    do
						  if [[ "$ACT" =~ "update" ]]
						  then
						    echo "======开始复制ims-gateway包到ops@\${HOST}======"
							scp -i ${KEY_DIR} -o StrictHostKeyChecking=no -P 60122  target/ims-gateway.jar  ops@\${HOST}.admin:/usr/local/src/java/gateway && \
			                echo "======复制完成======" && \
			                ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p 60122 ops@\${HOST}.admin  "sudo systemctl restart gateway.service"
						  fi
						    
						done
					fi
				"""
				}
		  }
		}
	  }
   }
}