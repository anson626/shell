pipeline {
  agent any
  environment {
	//包路径
	//SRC_DIR="/projects/backend/global-pf/"
	GIT_URL="git@gitlab.go016.com:pt-back/ims.git"
	KEY_DIR="/var/lib/jenkins/key/id_rsa"
  }
  parameters {
  gitParameter branch: '', branchFilter: '.*', defaultValue: 'ims_v2.2.0', description: '选择你的代码分支', name: 'BRANCH', quickFilterEnabled: false, selectedValue: 'NONE', sortMode: 'NONE', tagFilter: '*', type: 'GitParameterDefinition'
  }
  stages {
    stage('拉代码') {
        steps {
            checkout([$class: 'GitSCM', branches: [[name: "${BRANCH}"]], extensions: [], userRemoteConfigs: [[credentialsId: 'ssh-git-key', url: "${GIT_URL}"]]])
        }
    }
    stage('编译代码') {
        steps {
            sh """
            mvn clean install -Dmaven.test.skip=true
            """
        }
    }
    stage('更新admin主机运行的包') {
	  parallel {
	      //admin主机
	      stage('admin-api') {
			  steps {
				sh """
					if [[ "${admin_server}" =~ "admin-api" ]]
					then
                        for HOST in ${DEST_HOSTS};
                        do
						  if [[ "$ACT" =~ "update" ]]
                          then
						    echo "======开始复制admin-api包到ops@\${HOST}======"
                            scp -i ${KEY_DIR} -o StrictHostKeyChecking=no -P 60122 ims-api/ims-admin-api/target/ims-admin-api.jar ops@\${HOST}.admin:/usr/local/src/java/admin-api/ && \
                            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p 60122 ops@\${HOST}.admin  "sudo systemctl restart admin-api.service" && \
                            sleep  50 && \
							scp -i ${KEY_DIR} -o StrictHostKeyChecking=no -P 60122 ims-api/ims-admin-api/target/ims-admin-api.jar ops@\${HOST}.admin:/usr/local/src/java/lb-admin-api/ && \
                            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p 60122 ops@\${HOST}.admin  "sudo systemctl restart lb-admin-api.service" && 
                            echo "======重启服务完成======"
						  fi
						done
					fi
				"""
				}
		  }
		  
	      stage('betting-api') {
			  steps {
				sh """
					if [[ "${admin_server}" =~ "betting-api" ]]
					then
					    for HOST in ${DEST_HOSTS};
					    do
						  if [[ "$ACT" =~ "update" ]]
						  then
						    echo "======开始复制betting-api包到ops@\${HOST}======"
							scp -i ${KEY_DIR} -o StrictHostKeyChecking=no -P 60122 ims-api/ims-game-betting/target/ims-game-betting.jar ops@\${HOST}.admin:/usr/local/src/java/betting-api && \
                            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p 60122 ops@\${HOST}.admin  "sudo systemctl restart betting-api.service"
							echo "======重启服务完成======"
						  fi 
						done
					fi
				"""
				}
		  }
		  
	      stage('job-api') {
			  steps {
				sh """
					if [[ "${admin_server}" =~ "job-api" ]]
					then
					    for HOST in ${DEST_HOSTS};
					    do
						  if [[ "$ACT" =~ "update" ]]
						  then
						    echo "======开始复制job-api包到ops@\${HOST}======"
							scp -i ${KEY_DIR} -o StrictHostKeyChecking=no -P 60122 ims-api/ims-job-api/target/ims-job-api.jar ops@\${HOST}.admin:/usr/local/src/java/job-api/ && \
                            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p 60122 ops@\${HOST}.admin  "sudo systemctl restart job-api.service"
							echo "======复制完成======"
						  fi
						    echo "======重启服务完成======"
						done
					fi
				"""
				}
		  }
		  
	      stage('special-api') {
			  steps {
				sh """
					if [[ "${admin_server}" =~ "special-api" ]]
					then
					    for HOST in ${DEST_HOSTS};
					    do
						  if [[ "$ACT" =~ "update" ]]
						  then
						    echo "======开始复制special-api包到ops@\${HOST}======"
							scp -i ${KEY_DIR} -o StrictHostKeyChecking=no -P 60122 ims-api/ims-special-api/target/ims-special-api.jar ops@\${HOST}.admin:/usr/local/src/java/special-api/ && \
                            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p 60122 ops@\${HOST}.admin  "sudo systemctl restart special-api.service"
							echo "======复制完成======"
						  fi
						    echo "======重启服务完成======"
						done
					fi
				"""
				}
		  }
		  //api主机
          stage('activity-api') {
			  steps {
				sh """
					if [[ "${api_server}" =~ "activity-api" ]]
					then
					    for HOST in ${DEST_HOSTS};
					    do
							scp -i ${KEY_DIR} -o StrictHostKeyChecking=no -P 60022 ims-api/ims-activity-api/target/ims-activity-api.jar ops@\${HOST}.api:/usr/local/src/java/activity-api/ && \
					        scp -i ${KEY_DIR} -o StrictHostKeyChecking=no -P 60022 ims-api/ims-activity-api/target/ims-activity-api.jar ops@\${HOST}.api:/usr/local/src/java/lb-activity-api/ && \
                            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p 60022 ops@\${HOST}.api  "sudo systemctl restart activity-api.service" && \
                            sleep 40 && \
                            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p 60022 ops@\${HOST}.api  "sudo systemctl restart lb-activity-api.service"
							echo "======重启服务完成======"
						done
					fi
				"""
				}
		  }
		  
	      stage('business-api') {
			  steps {
				sh """
					if [[ "${api_server}" =~ "business-api" ]]
					then
					    for HOST in ${DEST_HOSTS};
					    do
						  if [[ "$ACT" =~ "update" ]]
						  then
						    echo "======开始复制special-api包到ops@\${HOST}======"
							scp -i ${KEY_DIR} -o StrictHostKeyChecking=no -P 60022 ims-api/ims-business-api/target/ims-business-api.jar ops@\${HOST}.api:/usr/local/src/java/business-api/ && \
					        scp -i ${KEY_DIR} -o StrictHostKeyChecking=no -P 60022 ims-api/ims-business-api/target/ims-business-api.jar ops@\${HOST}.api:/usr/local/src/java/lb-business-api/ && \
                            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p 60022 ops@\${HOST}.api  "sudo systemctl restart business-api.service" && \
                            sleep 40 && \
                            ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p 60022 ops@\${HOST}.api  "sudo systemctl restart lb-business-api.service"
							echo "======复制完成======"
						  fi
						    echo "======重启服务完成======"

						done
					fi
				"""
				}
		  }
		}
	  }
   }
}