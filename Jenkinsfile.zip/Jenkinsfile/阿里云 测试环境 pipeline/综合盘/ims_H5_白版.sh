
pipeline {
  agent any
  environment {
    SSH_USER = "ops"
    SSH_PORT = "62222"
    KEY_DIR="/var/lib/jenkins/key/id_rsa"
    DEST_HOST_DIR = "/usr/local/src/nginx/html/ims/h5"
    
  }
  parameters {
  gitParameter branch: '', branchFilter: '.*', defaultValue: 'master', description: '选择你的代码分支', name: 'BRANCH', quickFilterEnabled: false, selectedValue: 'NONE', sortMode: 'NONE', tagFilter: '*', type: 'GitParameterDefinition'
  }
  stages {
    stage("拉取代码"){
	   steps{
	     //git branch: "${BRANCH}", credentialsId: "${credentialsId}", url: "http://git.subocloud.com/pangpang/${GIT_URI}.git"
	     checkout([$class: 'GitSCM', branches: [[name: "${BRANCH}"]], extensions: [], userRemoteConfigs: [[credentialsId: 'ssh-git-key', url: "git@gitlab.go016.com:pt-front/h5_ims.git"]]])
		 }
	 }
    stage("编译代码并部署到服务器"){
	   steps{
	     nodejs('nodejs12') {

           sh"""
             npm i --unsafe-perm 
             for HOST in ${DEST_HOSTS};
             do
               npm run build
               tar czf dist.tar.gz dist && \
               ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p ${SSH_PORT} ${SSH_USER}@\${HOST}.front  "rm -rf ${DEST_HOST_DIR}/dist.tar.gz_bak;mv ${DEST_HOST_DIR}/dist.tar.gz ${DEST_HOST_DIR}/dist.tar.gz_bak" && \
               scp -P${SSH_PORT} -o StrictHostKeyChecking=no -i ${KEY_DIR} dist.tar.gz  ${SSH_USER}@\${HOST}.front:${DEST_HOST_DIR}/ && \
               ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p ${SSH_PORT} ${SSH_USER}@\${HOST}.front  "cd ${DEST_HOST_DIR} && rm -rf dist && tar --no-same-owner -xf dist.tar.gz "
             done
           """

		    }
		 }
	 }


     
  }
}