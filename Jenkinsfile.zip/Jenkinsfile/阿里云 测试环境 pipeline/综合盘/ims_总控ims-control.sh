pipeline {
  agent any
  environment {
	GIT_URL="git@gitlab.go016.com:pt-back/ims-control.git"
	KEY_DIR="/var/lib/jenkins/key/id_rsa"
    IP="172.16.60.132"
  }
  parameters {
  gitParameter branch: '', branchFilter: '.*', defaultValue: 'test-aliyun', description: '选择你的代码分支', name: 'BRANCH', quickFilterEnabled: false, selectedValue: 'NONE', sortMode: 'NONE', tagFilter: '*', type: 'GitParameterDefinition'
  }
  stages {
    stage('拉代码') {
        steps {
            checkout([$class: 'GitSCM', branches: [[name: "${BRANCH}"]], extensions: [], userRemoteConfigs: [[credentialsId: 'ssh-git-key', url: "${GIT_URL}"]]])
        }
    }
	stage('编译'){
		when {
			environment name: 'ACT',
			value: 'update'
		}
			steps{
				withMaven(maven: 'v3.6.3') {
					//mvn构建
					sh "cd ims-control &&mvn clean install -Dmaven.test.skip=true && ls -a"
				}
		}
	}
    stage('更新ims-control包并重新启动') {
	  parallel {
		  //api主机
          stage('ims-control') {
			  steps {
			    sh """
			        pwd
			        
				    scp -i ${KEY_DIR} -o StrictHostKeyChecking=no -P 62222 ims-control/ims-api/ims-control-api/target/ims-control-api.jar ops@${IP}:/usr/local/src/java/control/ && \
                    sleep 3 && \
                    ssh -i ${KEY_DIR} -o StrictHostKeyChecking=no -p 62222 ops@${IP}  "sudo systemctl restart control.service"  && \
				    echo "======重启服务完成======"
			    """
			}
		  }
		}
	  }
   }
}