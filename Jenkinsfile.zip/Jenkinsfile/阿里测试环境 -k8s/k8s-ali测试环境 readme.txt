新阿里测试环境K8S资料
文件位置在内网172.16.9.141主机上的/usr/local/src

ingress
部署方式 helm
名称空间 ingress
使用 daemonset 控制器部署
使用 标签选择器 特定主机主机部署 
使用 阿里的负载均衡引入流量到集群中ingress 因为使用了host网络 所以是特定主机的80 端口 去阿里页面一看便知
是用 host网络
helm_chart目录 /usr/local/src/helm_chart/ingress

ingress_yaml
使用ingress暴露服务的域名
服务对应关系  见名知意
目录  /usr/local/src/ingress_yaml

jenkins
集群外部署四层白名单 地址 http://47.243.61.224:8080 
用户密码找edison
但172.16.9.141主机上/usr/local/src/jenkins 有一个PVC 是JAVA项目编译时持久化maven 和gradle 依赖包的

nacos 
给支付组单独使用的nacos 测试环境其他组不使用nacos
使用资源清单部署 
名称空间 nacos
单独集群内mysql数据库也是资源换清单部署
文件位置 /usr/local/src/nacos

redis
使用helm部署 
单机单节点
名称空间  redis
helm_chart目录 /usr/local/src/helm_chart/redis

业务服务
使用jenkins流水线部署 资源清单见流水线



-----------------------------------

这里面没什么涉及复杂性的东西  都是一些基础概念的东西  如果迁移生产 你还要了解  kube-prometheus 他是一个operator 控制器 作为监控告警组件  此前的生产 因为用了kubesphere 自带的prometheus 没有办法实现高级的监控项定制 汉化 和告警的webhook路由  所以我就没动

还有日志系统  日志系统 由于我们规模比较小 用不到那些高级的 比如eck  logging-operator之类的东西 建议使用loki就好了

loki+promtail 使用helm 部署 也很方便