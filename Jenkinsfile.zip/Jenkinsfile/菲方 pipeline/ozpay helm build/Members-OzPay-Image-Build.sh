def ERROR_MESSAGE
boolean PIPELINE_SUCCESS = true

pipeline {
    agent any
  
    tools {
        dockerTool 'docker'
    }
  
    environment 
    {
        ENVIRONMENT = 'production'
        REGISTRY = 'harbor-ali.mir708090.com'
        DOCKER_REPOSITORY_SERVER = "https://${REGISTRY}"
        HARBOR_ID = 'harbor-ali'
        DOCKERHUB_NAMESPACE = "ozpay/${ENVIRONMENT}"
        IMAGE_REPOSITORY = "members"
        GITLAB_CREDENTIALS = 'gitlab-opayant'
        GITLAB_REPOSITORY_URL = 'git@gitlab.com:m9996/opay-member.git'
        SCAPED_BRANCH_NAME = BRANCH.replaceAll('/','-')

        BOT_TOKEN = 'bot5405564816%3AAAGha_5I23kbupAfqy8aK4pXUz7hXU7CBPM' //DevOps Bot
        CHAT_ID = '5323458396' //Personal Page
        //CHAT_ID = '-733433470' // CICD for Opayant Channel
        DISABLE_NOTIFICATION = 'false'
        PROJECT_NAME = "OzPay-Members"

        BUILD_TRIGGER_BY = "${currentBuild.getBuildCauses()[0].shortDescription} / ${currentBuild.getBuildCauses()[0].userId}"
        GIT_COMMIT_HASH = "Error"
    }

    stages 
    {

        stage ('Checkout GitSCM')
        {
            steps
            {
                script
                {
                    try 
                    {
                        BUILD_TRIGGER_BY = "${currentBuild.getBuildCauses()[0].shortDescription} / ${currentBuild.getBuildCauses()[0].userId}"
                        checkout([
                            $class: 'GitSCM', 
                                branches: [[
                                name: "*/${BRANCH}"
                            ]], 
                            doGenerateSubmoduleConfigurations: false, 
                             extensions: [[
                                $class: 'CloneOption', 
                                timeout: 20, 
                                noTags: false
                            ]], 
                            submoduleCfg: [], 
                            userRemoteConfigs: [[
                                credentialsId: "${GITLAB_CREDENTIALS}", 
                                url: "${GITLAB_REPOSITORY_URL}"]]
                            ])
                        sh "ls -lah ./"
                        GIT_COMMIT_HASH = sh (script: "git rev-parse --short HEAD", returnStdout: true).trim()
                    }
                    catch(e)
                    {
                        PIPELINE_SUCCESS = false
                        ERROR_MESSAGE = "${ERROR_MESSAGE} ${e} \n" 
                        print e
                        currentBuild.result = 'FAILURE'
                    }
                }
            }
        }

        stage ('Pre-Build Notification')
        {
            steps
            {
                script
                {
                    notification("🔧 We are building rockets!")
                }
            }

        }

        stage("Build image") 
        {
            steps 
            {
                script 
                {
                    try {
                        docker.build("${REGISTRY}/${DOCKERHUB_NAMESPACE}/${IMAGE_REPOSITORY}:${SCAPED_BRANCH_NAME}-${GIT_COMMIT_HASH}", "--no-cache .")
                        docker.withRegistry("${DOCKER_REPOSITORY_SERVER}", "${HARBOR_ID}")
                        {
                            docker.image("$REGISTRY/$DOCKERHUB_NAMESPACE/${IMAGE_REPOSITORY}:${SCAPED_BRANCH_NAME}-${GIT_COMMIT_HASH}").push()
                            docker.image("$REGISTRY/$DOCKERHUB_NAMESPACE/${IMAGE_REPOSITORY}:${SCAPED_BRANCH_NAME}-${GIT_COMMIT_HASH}").push("latest")
                        }
                    }
                    catch(e)
                    {
                        PIPELINE_SUCCESS = false
                        ERROR_MESSAGE = "${ERROR_MESSAGE} ${e} \n"
                        print e
                        currentBuild.result = 'FAILURE'
                    }
                }
            }
        }
    }

    post
    {
        always
        {
            script
            {
                if (!PIPELINE_SUCCESS)
                {
                    notification("❗ Build Error! \n\n ${ERROR_MESSAGE}")
                }
                else
                {
                    notification("✅ Build Success! \n\nThe rocket is now ready to lift off!")
                }
                cleanWs()
            }
        }
    }
}

def notification(status)
{
    sh """
        curl --request POST \
        --url https://api.telegram.org/${BOT_TOKEN}/sendMessage \
        --header 'Accept: application/json' \
        --header 'Content-Type: application/json' \
        --header 'User-Agent: Telegram Bot SDK - (https://github.com/irazasyed/telegram-bot-sdk)' \
        --data '
        {
        "text": "
${status}

${BUILD_TRIGGER_BY}

Project Name: ${PROJECT_NAME}
Environment: ${ENVIRONMENT}
Branch: ${BRANCH}
Commit Hash: ${GIT_COMMIT_HASH}
Docker Image: ${REGISTRY}/${DOCKERHUB_NAMESPACE}/${IMAGE_REPOSITORY}
Docker Image Tag: ${SCAPED_BRANCH_NAME}-${GIT_COMMIT_HASH}
Build URL: ${BUILD_URL}
            ",
        "disable_web_page_preview": false,
        "disable_notification": ${DISABLE_NOTIFICATION},
        "reply_to_message_id": null,
        "chat_id": "${CHAT_ID}"
        }
        '
    """
}