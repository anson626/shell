pipeline {
  agent any
  environment {
      host="172.31.1.119"
      ezbasedir="/var/www/ezpay"
      env_prod_file="/var/www/ezpay/envs/.env.production"
      tarbased="/var/lib/jenkins/backup/ezpay"
  }
  stages {
      stage('Pull Code') {
          when {
              environment name: 'ACT',
			  value: 'update'
          }
          steps {
              checkout([$class: 'GitSCM',
                  branches: [[name: "${BRANCH_TAG}"]],
                  doGenerateSubmoduleConfigurations: false,
                  extensions: [],
                  submoduleCfg: [],
                  userRemoteConfigs: [[
                            credentialsId: 'jenkins-ssh',
                            url: 'ssh://git@gitlab.com/m.loquero.melvin/zpay.git'
                            ]]
                  ])
          }
      }
      stage('Transfer Files') {
           when {
              environment name: 'ACT',
			  value: 'update'
          }
          steps {
              sh """
              date_build=`date -d today '+%Y%m%d'`
              tar -czvf \${tarbased}/ezpay_\${date_build}.tar *
              scp -o StrictHostKeyChecking=no -P'11618' \${tarbased}/ezpay_\${date_build}.tar  ezpay@\${host}:/var/www/
              ssh -o StrictHostKeyChecking=no -p'11618' ezpay@\${host} "ls /var/www/ezpay_\${date_build}.tar" || exit 1
              """
          }       
      }
      stage('Stop NPM') {
          when {
              anyOf {
                  environment name: 'ACT',
			      value: 'update';
					
			      environment name: 'ACT',
			      value: 'rollback';
			      
			      environment name: 'ACT',
			      value: 'stop';
              }
          }
          steps {
              sh """
              ssh -p 11618 -o StrictHostKeyChecking=no ezpay@\${host} -tt <<remotessh
                 sudo systemctl stop nginx
                 cd \${ezbasedir}
                 npm run pm2:stop
              
              exit
remotessh
              """
          }
      }
      stage('Update files') {
           when {
              environment name: 'ACT',
			  value: 'update'
          }
          steps {
              sh """
              date_build=`date -d today '+%Y%m%d'`
              ssh -p 11618 -o StrictHostKeyChecking=no ezpay@\${host} -tt <<remotessh
              rm -rf /var/www/bak_ezpay.tar
              cd /var/www/ezpay
              cp -f \${env_prod_file} /var/www/
              tar --exclude="/var/www/ezpay/package.json" -czvf /var/www/bak_ezpay.tar * --remove-files
              cd ..
              tar -xzvf ezpay_\${date_build}.tar -C ezpay/
              cp -f .env.production \${env_prod_file}
              rm -f ezpay_\${date_build}.tar
              exit
remotessh
              """
          }
      }
      stage('Rollback') {
          when {
              anyOf {
			      environment name: 'ACT',
			      value: 'rollback';
			      
              }
          }
          steps {
              sh """
              ssh -p 11618 -o StrictHostKeyChecking=no ezpay@\${host} -tt <<remotessh
              cd /var/www
              cp ezpay/package.json .
              rm -rf ezpay/*
              tar -xzvf bak_ezpay.tar -C ezpay/
              cp package.json ezpay/
              exit
remotessh
              """
          }
      }
      stage('Compile') {
          when {
              anyOf {
                  environment name: 'ACT',
			      value: 'update';
			      
			      environment name: 'ACT',
			      value: 'rollback';
              }    
          }
          steps {
              sh """
              ssh -p 11618 -o StrictHostKeyChecking=no ezpay@\${host} -tt <<remotessh
              pm2 delete 0
              cd \${ezbasedir}
              npm install && \
              npm run build && \
              exit
remotessh
              """
          }
      }
      stage('Start NPM') {
          when {
              anyOf {
                  environment name: 'ACT',
			      value: 'update';
					
			      environment name: 'ACT',
			      value: 'rollback';
					
			      environment name: 'ACT',
			      value: 'start';
              }
          }
          steps {
              sh """
              rm -f \${tarbased}/*
              ssh -p 11618 -o StrictHostKeyChecking=no ezpay@\${host} -tt <<remotessh
              cd \${ezbasedir}
              npm run pm2:start
              sudo systemctl start nginx
              exit
remotessh
              """
          }
      }
  } 
}