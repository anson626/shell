
pipeline {
  agent any
  environment {
	//ssh port
	SSH_PORT="11618"
	//opay env file
	env_prod_file=".env.production"
	
  }
  stages {
      
    stage('PULL CODE') {
      when {
          environment name: 'TASK',
          value: 'update'
      }
      steps {
          script {
             def DEST_HOSTS = DEST_HOSTS.split(',')
             for (String IP: DEST_HOSTS) {
            
if (IP == 'prod_backend') {
    url = 'git@gitlab.com:o998/opay-backend.git'
    hostip = '172.31.14.2'
    tarbased = '~/backup/opay/backend'
    appbased = '/data/apps/opay-backend'
} else if (IP == 'prod_member_frontend') {
    url = 'git@gitlab.com:o998/opay-member-frontend.git'
    hostip = '172.31.14.154'
    tarbased = '~/backup/opay/member'
    appbased = '/data/apps/opay-member'
} else if (IP == 'prod_admin_frontend') {
    url = 'git@gitlab.com:o998/opay-admin-frontend.git'
    hostip = '172.31.14.233'
    tarbased = '~/backup/opay/admin'
    appbased = '/data/apps/opay-admin'
}
                 
                  checkout([$class: 'GitSCM',
                  doGenerateSubmoduleConfigurations: false,
                  extensions: [],
                  submoduleCfg: [],
                  userRemoteConfigs: [[
                            url: "${url}",
                            credentialsId: 'jenkins-ssh'
                            ]],
                  branches: [[
                            name: "${BRANCH_TAG}"
                            ]]
                  ])
                  
                   sh """
                     git branch -a
                     date_build=`date -d today '+%Y%m%d'`
                     tar -czvf ${tarbased}/opay_\${date_build}.tar *
                     rm -rf *
                  """
             }
          }
       }
    }
    stage('TRANSFER FILES') {
      when {
          environment name: 'TASK',
          value: 'update'
      }
      steps {
          script {
             def DEST_HOSTS = DEST_HOSTS.split(',')
             for (String IP: DEST_HOSTS) {
            
if (IP == 'prod_backend') {
    url = 'git@gitlab.com:o998/opay-backend.git'
    hostip = '172.31.14.2'
    tarbased = '~/backup/opay/backend'
    appbased = '/data/apps/opay-backend'
} else if (IP == 'prod_member_frontend') {
    url = 'git@gitlab.com:o998/opay-member-frontend.git'
    hostip = '172.31.14.154'
    tarbased = '~/backup/opay/member'
    appbased = '/data/apps/opay-member'
} else if (IP == 'prod_admin_frontend') {
    url = 'git@gitlab.com:o998/opay-admin-frontend.git'
    hostip = '172.31.14.233'
    tarbased = '~/backup/opay/admin'
    appbased = '/data/apps/opay-admin'
}

          sh """
              date_build=`date -d today '+%Y%m%d'`
              scp -o StrictHostKeyChecking=no -P\${SSH_PORT} ${tarbased}/opay_\${date_build}.tar  devops@${hostip}:/data/apps/
              ssh -o StrictHostKeyChecking=no -p\${SSH_PORT} devops@${hostip} "ls /data/apps/opay_\${date_build}.tar" || exit 1
              rm -f ${tarbased}/opay_\${date_build}.tar
          """
             }
          }
      }
    }
    stage('Stop NPM') {
      when {
          anyOf {
                 environment name: 'TASK',
		         value: 'update';
					
	    	     environment name: 'TASK',
			     value: 'rollback';
			      
			     environment name: 'TASK',
			     value: 'stop';
          }
      }
      steps {
          script {
             def DEST_HOSTS = DEST_HOSTS.split(',')
             for (String IP: DEST_HOSTS) {
            
if (IP == 'prod_backend') {
    url = 'git@gitlab.com:o998/opay-backend.git'
    hostip = '172.31.14.2'
    tarbased = '~/backup/opay/backend'
    appbased = '/data/apps/opay-backend'
} else if (IP == 'prod_member_frontend') {
    url = 'git@gitlab.com:o998/opay-member-frontend.git'
    hostip = '172.31.14.154'
    tarbased = '~/backup/opay/member'
    appbased = '/data/apps/opay-member'
    sh 'sudo systemctl stop nginx'
} else if (IP == 'prod_admin_frontend') {
    url = 'git@gitlab.com:o998/opay-admin-frontend.git'
    hostip = '172.31.14.233'
    tarbased = '~/backup/opay/admin'
    appbased = '/data/apps/opay-admin'
    sh 'sudo systemctl stop nginx'
}
              sh """
              ssh -p \${SSH_PORT} -o StrictHostKeyChecking=no devops@${hostip} -tt <<remotessh

                 cd ${appbased}
                 npm run pm2:stop
              
              exit
remotessh
              """
             }
          }
         }
    }
    stage('UPDATE FILES') {
      when {
             environment name: 'TASK',
			 value: 'update'
      }
      steps {
          script {
             def DEST_HOSTS = DEST_HOSTS.split(',')
             for (String IP: DEST_HOSTS) {
            
if (IP == 'prod_backend') {
    url = 'git@gitlab.com:o998/opay-backend.git'
    hostip = '172.31.14.2'
    tarbased = '~/backup/opay/backend'
    appbased = '/data/apps/opay-backend'
} else if (IP == 'prod_member_frontend') {
    url = 'git@gitlab.com:o998/opay-member-frontend.git'
    hostip = '172.31.14.154'
    tarbased = '~/backup/opay/member'
    appbased = '/data/apps/opay-member'
} else if (IP == 'prod_admin_frontend') {
    url = 'git@gitlab.com:o998/opay-admin-frontend.git'
    hostip = '172.31.14.233'
    tarbased = '~/backup/opay/admin'
    appbased = '/data/apps/opay-admin'
}
            sh """
              date_build=`date -d today '+%Y%m%d'`
              
              ##//building apps in target host
              ssh -p \${SSH_PORT} -o StrictHostKeyChecking=no devops@${hostip} -tt <<remotessh
              
              ##// clean old backup
              rm -rf /data/apps/bak_opay.tar
              
              ##//backup current env files
              cd ${appbased}
              cp -f ${appbased}/envs/\${env_prod_file} /data/apps/
              
              ##//backup current app files
              tar --exclude="${appbased}/package.json" -czvf /data/apps/bak_opay.tar * --remove-files
              cd ..
              
              ##//extract update files
              tar -xzvf opay_\${date_build}.tar -C ${appbased}
              cp -f \${env_prod_file} ${appbased}/envs/\${env_prod_file}
              
              ##//clean up update tar files
              pwd
              rm -f opay_\${date_build}.tar
              exit
remotessh
              """
             }
          }
         }
      }  
      stage('ROLLBACK') {
          when {
              anyOf {
			      environment name: 'TASK',
			      value: 'rollback';
			      
              }
          }
          steps {
              script {
             def DEST_HOSTS = DEST_HOSTS.split(',')
             for (String IP: DEST_HOSTS) {
            
if (IP == 'prod_backend') {
    url = 'git@gitlab.com:o998/opay-backend.git'
    hostip = '172.31.14.2'
    tarbased = '~/backup/opay/backend'
    appbased = '/data/apps/opay-backend'
} else if (IP == 'prod_member_frontend') {
    url = 'git@gitlab.com:o998/opay-member-frontend.git'
    hostip = '172.31.14.154'
    tarbased = '~/backup/opay/member'
    appbased = '/data/apps/opay-member'
} else if (IP == 'prod_admin_frontend') {
    url = 'git@gitlab.com:o998/opay-admin-frontend.git'
    hostip = '172.31.14.233'
    tarbased = '~/backup/opay/admin'
    appbased = '/data/apps/opay-admin'
}
              sh """
              ssh -p \${SSH_PORT} -o StrictHostKeyChecking=no devops@${hostip} -tt <<remotessh
              cd /data/apps
              cp ${appbased}/package.json .
              rm -rf ${appbased}/*
              tar -xzvf bak_opay.tar -C ${appbased}/
              cp -f package.json ${appbased}/
              exit
remotessh
              """
             }
            }
         }
      }    
            stage('COMPILE') {
          when {
              anyOf {
                  environment name: 'TASK',
			      value: 'update';
			      
			      environment name: 'TASK',
			      value: 'rollback';
              }    
          }
          steps {
              script {
             def DEST_HOSTS = DEST_HOSTS.split(',')
             for (String IP: DEST_HOSTS) {
            
if (IP == 'prod_backend') {
    url = 'git@gitlab.com:o998/opay-backend.git'
    hostip = '172.31.14.2'
    tarbased = '~/backup/opay/backend'
    appbased = '/data/apps/opay-backend'
} else if (IP == 'prod_member_frontend') {
    url = 'git@gitlab.com:o998/opay-member-frontend.git'
    hostip = '172.31.14.154'
    tarbased = '~/backup/opay/member'
    appbased = '/data/apps/opay-member'
} else if (IP == 'prod_admin_frontend') {
    url = 'git@gitlab.com:o998/opay-admin-frontend.git'
    hostip = '172.31.14.233'
    tarbased = '~/backup/opay/admin'
    appbased = '/data/apps/opay-admin'
}
              sh """
              ssh -p \${SSH_PORT} -o StrictHostKeyChecking=no devops@${hostip} -tt <<remotessh
              cd ${appbased}
              npm install && \
              npm run build && \
              exit
remotessh
              """
             }
            }
          }
      }
      stage('START NPM') {
          when {
              anyOf {
                  environment name: 'TASK',
			      value: 'update';
					
			      environment name: 'TASK',
			      value: 'rollback';
					
			      environment name: 'TASK',
			      value: 'start';
              }
          }
          steps {
              script {
             def DEST_HOSTS = DEST_HOSTS.split(',')
             for (String IP: DEST_HOSTS) {
            
if (IP == 'prod_backend') {
    url = 'git@gitlab.com:o998/opay-backend.git'
    hostip = '172.31.14.2'
    tarbased = '~/backup/opay/backend'
    appbased = '/data/apps/opay-backend'
} else if (IP == 'prod_member_frontend') {
    url = 'git@gitlab.com:o998/opay-member-frontend.git'
    hostip = '172.31.14.154'
    tarbased = '~/backup/opay/member'
    appbased = '/data/apps/opay-member'
    sh 'sudo systemctl start nginx'
} else if (IP == 'prod_admin_frontend') {
    url = 'git@gitlab.com:o998/opay-admin-frontend.git'
    hostip = '172.31.14.233'
    tarbased = '~/backup/opay/admin'
    appbased = '/data/apps/opay-admin'
    sh 'sudo systemctl start nginx'
}
              sh """
              
              ssh -p \${SSH_PORT} -o StrictHostKeyChecking=no devops@${hostip} -tt <<remotessh
              cd ${appbased}
              npm run pm2:start
              exit
remotessh
              """
             }
            }
          }
      }
  }
}
