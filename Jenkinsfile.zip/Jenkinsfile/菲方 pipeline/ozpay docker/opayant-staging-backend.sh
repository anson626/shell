pipeline {
  agent none
  
    tools {
        dockerTool 'docker'
    }
  
 
    environment {
        //DOCKER_CREDENTIAL_ID = 'harbor-id'
        //GITHUB_CREDENTIAL_ID = 'github-id'
        //KUBECONFIG_CREDENTIAL_ID = 'kubeconfig'
        REGISTRY = 'harbor-dev.mir708090.com'
        DOCKERHUB_NAMESPACE = 'opayant-staging'
        //GITHUB_ACCOUNT = 'admin'
        //APP_NAME = 'guns-kubesphere'
        //DOCKER_USERNAME = 'admin'
    }
 
    stages {
        stage ('Checkout GitSCM') {
            agent {
                docker { image 'maven:3.8.1-adoptopenjdk-11' }
                //reuseNode true
            }
            steps {
                checkout([$class: 'GitSCM', branches: [[name: '$branch']], doGenerateSubmoduleConfigurations: false, extensions: [[
                                                                                  $class: 'SubmoduleOption', 
                                                                                  disableSubmodules: false, 
                                                                                  parentCredentials: true, 
                                                                                  recursiveSubmodules: true, 
                                                                                  reference: '', 
                                                                                  trackingSubmodules: false
                                                                                  ]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'gitlab-opayant', url: 'git@gitlab.com:m9996/opayant-api.git']]])
            }
        }
         
        stage ('Compile App') {
          //when{
           // anyOf{
             // environment name: 'ACT',
             // value: 'NEW'
             // environment name: 'ACT',
             // value: 'UPDATE'
             // }
           // }
            agent {
                docker { image 'maven:3.8.1-adoptopenjdk-11' }
                //reuseNode true
            }
            steps {
              
                sh 'mvn -f pom.xml clean install -Dmaven.test.skip=true'
            
        }
    }
         
        stage("Build image") {
          when {
            anyOf {
              environment name: 'ACT',
              value: 'NEW'
              environment name: 'ACT',
              value: 'UPDATE'
            }
          }
          //agent { label 'master' }
            steps {
                script {
                    
                    docker.build("${REGISTRY}/${DOCKERHUB_NAMESPACE}/${branch}:SNAPSHOT-${BUILD_NUMBER}", "--no-cache .")
                    docker.withRegistry('https://harbor-dev.mir708090.com', 'harbor-id') {
                    docker.image("$REGISTRY/$DOCKERHUB_NAMESPACE/$branch:SNAPSHOT-$BUILD_NUMBER").push()
                    docker.image("$REGISTRY/$DOCKERHUB_NAMESPACE/$branch:SNAPSHOT-$BUILD_NUMBER").push("latest")
                    }
                }
                    //sh 'docker build -f Dockerfile -t $REGISTRY/$DOCKERHUB_NAMESPACE/$branch:SNAPSHOT-$BUILD_NUMBER .'
                    //withCredentials([usernamePassword(credentialsId : 'harbor-id' ,passwordVariable : 'DOCKER_PASSWORD' ,usernameVariable : 'DOCKER_USERNAME' ,)]) {
                    //sh 'echo "$DOCKER_PASSWORD" | docker login $REGISTRY -u "$DOCKER_USERNAME" --password-stdin'
                    //sh 'docker push $REGISTRY/$DOCKERHUB_NAMESPACE/$APP_NAME:SNAPSHOT-$BUILD_NUMBER'
                //}
               
            }
        }
        //stage ("Push latest Image") {
        //  steps {
        //      container ('maven') {          
        //            sh 'docker tag $REGISTRY/$DOCKERHUB_NAMESPACE/$APP_NAME:SNAPSHOT-$BUILD_NUMBER $REGISTRY/$DOCKERHUB_NAMESPACE/$APP_NAME/prod:latest'
        //            withCredentials([usernamePassword(credentialsId : 'harbor-id' ,passwordVariable : 'DOCKER_PASSWORD' ,usernameVariable : 'DOCKER_USERNAME' ,)]) {
        //            sh 'echo "$DOCKER_PASSWORD" | docker login $REGISTRY -u "$DOCKER_USERNAME" --password-stdin'
        //            sh 'docker push $REGISTRY/$DOCKERHUB_NAMESPACE/$APP_NAME:latest'
        //            }
        //        }
        //    }
        //}
         
        stage('Deploy App') {
          when {
            anyOf {
              environment name: 'ACT',
              value: 'NEW'
              environment name: 'ACT',
              value: 'UPDATE'
            }
          }
          agent any
          steps {
            //input(id: 'deploy-to-production', message: 'deploy to production?')
            //kubernetesDeploy(configs: 'guns/deployment.yml', enableConfigSubstitution: true, kubeconfigId: "kubeconfig")
            sh """
              ssh -p 11618 -o StrictHostKeyChecking=no devops@54.169.133.41 -tt <<remotessh
                 echo $dpassword | docker login $REGISTRY -u admin --password-stdin
                 cd opay-docker-compose
                 docker-compose -f opayantapi.yml down
                 sed -i 's#$DOCKERHUB_NAMESPACE/$branch:SNAPSHOT-.*#$DOCKERHUB_NAMESPACE/$branch:SNAPSHOT-$BUILD_NUMBER#' opayantapi.yml
                 sleep 5
                 docker-compose -f opayantapi.yml up -d
                 sleep 15
                 curl 'https://api.telegram.org/bot5449202219:AAHXtCnC5ToAkGidh9Wopld-m4HViUeCQPY/sendMessage?chat_id=-733433470&text=Done API deployment with BUILD no.$BUILD_NUMBER'
              exit
remotessh
              """
          }
        }
    }
}