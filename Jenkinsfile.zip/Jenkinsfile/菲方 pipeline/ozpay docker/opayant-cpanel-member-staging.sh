pipeline {
  agent none
  
    tools {
        dockerTool 'docker'
    }
  
 
    environment {
        //DOCKER_CREDENTIAL_ID = 'harbor-id'
        //GITHUB_CREDENTIAL_ID = 'github-id'
        //KUBECONFIG_CREDENTIAL_ID = 'kubeconfig'
        REGISTRY = 'harbor-dev.mir708090.com'
        DOCKERHUB_NAMESPACE = 'opayant-staging'
        //GITHUB_ACCOUNT = 'admin'
        //APP_NAME = 'guns-kubesphere'
        //DOCKER_USERNAME = 'admin'
    }
 
    stages {

        stage('Deploy App') {
          agent any
          steps {
            //input(id: 'deploy-to-production', message: 'deploy to production?')
            //kubernetesDeploy(configs: 'guns/deployment.yml', enableConfigSubstitution: true, kubeconfigId: "kubeconfig")
            sh """
              ssh -p 11618 -o StrictHostKeyChecking=no devops@13.215.85.34 -tt <<remotessh
				 
                 docker-compose -f opay-member/docker/docker-compose.yml down
                 mv opay-member opay-member.$BUILD_NUMBER
				 git clone -b develop https://dennz:$dpassword@gitlab.com/m9996/opay-member.git
				 sed -i '9,11d' opay-member/docker/docker-compose.yml
                 sed -i 's#opayant-dist#/opt/opayant/opayant-member-dist#' opay-member/docker/docker-compose.yml
				 sed -i 's#8080#8000#' opay-member/Dockerfile
				 sudo mv /opt/opayant/opayant-member-dist /opt/opayant/opayant-member-dist.$BUILD_NUMBER
				 docker rmi docker_opayant_member
				 cd opay-member
				 docker-compose -f docker/docker-compose.yml build --no-cache
				 docker-compose -f docker/docker-compose.yml up
				 sleep 5
				 sudo nginx -s reload
				 curl 'https://api.telegram.org/bot5449202219:AAHXtCnC5ToAkGidh9Wopld-m4HViUeCQPY/sendMessage?chat_id=-733433470&text=Done member deployment with BUILD no.$BUILD_NUMBER'
				 sleep 10
				 cd
				 docker-compose -f opay-cpanel/docker/docker-compose.yml down
                 mv opay-cpanel opay-cpanel.$BUILD_NUMBER
				 git clone -b develop https://dennz:$dpassword@gitlab.com/m9996/opay-cpanel.git
				 sed -i '9,11d' opay-cpanel/docker/docker-compose.yml
                 sed -i 's#opayant-dist#/opt/opayant/opayant-cpanel-dist#' opay-cpanel/docker/docker-compose.yml
				 sed -i 's#8080#8000#' opay-cpanel/Dockerfile
				 sudo mv /opt/opayant/opayant-cpanel-dist /opt/opayant/opayant-cpanel-dist.$BUILD_NUMBER
				 docker rmi docker_opayant_cpanel
				 sudo systemctl restart docker
				 sleep 10
				 docker-compose -f oa-cpanel/docker/docker-compose.dev.yml start
				 cd opay-cpanel
				 docker-compose -f docker/docker-compose.yml build --no-cache
				 docker-compose -f docker/docker-compose.yml up
				 sleep 60
				 curl 'https://api.telegram.org/bot5449202219:AAHXtCnC5ToAkGidh9Wopld-m4HViUeCQPY/sendMessage?chat_id=-733433470&text=Done cpanel deployment with BUILD no.$BUILD_NUMBER'
				 sudo nginx -s reload
              
              exit
remotessh
              """
          }
        }
    }
}