在安装之前需要创建和配置这三个文件

/docker-app/prometheus_monitor/prometheus/config/
alertmanager.yml
blackbox.yml
prometheus.yml


在启动docker file 需要加上 
user: root
